#!/bin/bash
whoami
