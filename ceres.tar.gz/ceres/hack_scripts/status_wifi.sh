#!/bin/bash
connmanctl technologies
