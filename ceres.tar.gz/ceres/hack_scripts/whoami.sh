#!/bin/bash
/home/ceres/utilities/runas /home/ceres/utilities/whoami.sh
