#!/bin/bash
/home/ceres/utilities/runas /home/ceres/utilities/remove_keyboard_device.sh
