#!/bin/bash
connmanctl disable wifi
