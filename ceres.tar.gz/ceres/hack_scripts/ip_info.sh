#!/bin/bash
/usr/sbin/ip a
