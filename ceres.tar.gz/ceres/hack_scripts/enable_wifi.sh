#!/bin/bash
connmanctl enable wifi
