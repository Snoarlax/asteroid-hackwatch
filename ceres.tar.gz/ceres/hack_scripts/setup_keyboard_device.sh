#!/bin/bash
/home/ceres/utilities/runas /home/ceres/utilities/setup_keyboard_device.sh
